/* global LP_Admin, wp */
( function ( $ ) {
    'use strict';

    // Messages may come from AJAX responses, so always insert them as text.
    function showToast( message, type ) {
        const toast = $( '<div>' )
            .addClass( 'lp-toast lp-toast--' + ( type === 'success' ? 'success' : 'error' ) )
            .attr( 'role', type === 'success' ? 'status' : 'alert' )
            .text( message );
        $( 'body' ).append( toast );
        setTimeout( () => toast.addClass( 'lp-toast--visible' ), 10 );
        setTimeout( function () {
            toast.removeClass( 'lp-toast--visible' );
            setTimeout( () => toast.remove(), 300 );
        }, 3000 );
    }

    $( '.lp-color-picker' ).wpColorPicker( { change: updateDesignPreview } );

    $( '#lp_switcher_display' ).on( 'change', function () {
        $( '.lp-page-selector' ).toggle( $( this ).val() !== 'all' );
    } );

    $( document ).on( 'change', '.lp-lang-card input[type="checkbox"]', function () {
        $( this ).closest( '.lp-lang-card' ).toggleClass( 'lp-lang-card--active', this.checked );
    } );

    // Save a single translation row from the translations table.
    $( document ).on( 'click', '.lp-save-translation', function () {
        const $btn       = $( this );
        const $cell      = $btn.closest( 'td' );
        const $input     = $cell.find( '.lp-translation-input' );
        const $select    = $cell.find( '.lp-status-select' );
        const $badge     = $cell.find( '.lp-status-badge' );
        const translated = $input.val();

        $btn.prop( 'disabled', true ).text( '…' );

        // .attr(), not .data(): jQuery's .data() type-converts values, so an
        // original text like "1e3" or "[1]" would be sent as 1000 or an array.
        $.post( LP_Admin.ajaxUrl, {
            action:     'lp_save_translation',
            nonce:      LP_Admin.nonce,
            hash:       $btn.attr( 'data-hash' ),
            lang:       $btn.attr( 'data-lang' ),
            original:   $btn.attr( 'data-original' ),
            translated: translated,
            status:     $select.val(),
        } )
        .done( function ( res ) {
            if ( res.success ) {
                // The server auto-activates when translated_text is non-empty; reflect that here.
                const effectiveStatus = translated.trim() !== '' ? 'active' : $select.val();
                $badge.removeClass( 'lp-status--active lp-status--pending lp-status--ignored' )
                      .addClass( 'lp-status--' + effectiveStatus )
                      .text( LP_Admin.i18n[ effectiveStatus ] || effectiveStatus );
                $select.val( effectiveStatus );
                $cell.addClass( 'lp-save-success' );
                setTimeout( () => $cell.removeClass( 'lp-save-success' ), 700 );
            } else {
                showToast( res.data?.message || LP_Admin.i18n.error, 'error' );
            }
        } )
        .fail( () => showToast( LP_Admin.i18n.error, 'error' ) )
        .always( function () {
            $btn.prop( 'disabled', false ).text( '✓' );
            setTimeout( () => $btn.text( LP_Admin.i18n.saveBtn ), 1500 );
        } );
    } );

    $( document ).on( 'change', '.lp-status-select', function () {
        const $select = $( this );
        const entryId = $select.data( 'entry-id' );
        const status  = $select.val();
        const $badge  = $select.closest( 'td' ).find( '.lp-status-badge' );

        if ( ! entryId ) return;

        $.post( LP_Admin.ajaxUrl, { action: 'lp_update_status', nonce: LP_Admin.nonce, id: entryId, status } )
            .done( function ( res ) {
                if ( res.success ) {
                    $badge.removeClass( 'lp-status--active lp-status--pending lp-status--ignored' )
                          .addClass( 'lp-status--' + status )
                          .text( LP_Admin.i18n[ status ] || status );
                }
            } );
    } );

    $( document ).on( 'click', '.lp-delete-translation', function () {
        if ( ! confirm( LP_Admin.i18n.confirm ) ) return;

        const $btn = $( this );
        const $row = $btn.closest( 'tr' );

        $.post( LP_Admin.ajaxUrl, {
            action: 'lp_delete_translation',
            nonce:  LP_Admin.nonce,
            hash:   $row.attr( 'data-hash' ),
        } )
        .done( function ( res ) {
            if ( res.success ) {
                $row.fadeOut( 300, () => $row.remove() );
                showToast( LP_Admin.i18n.deleted, 'success' );
            } else {
                showToast( res.data?.message || LP_Admin.i18n.error, 'error' );
            }
        } )
        .fail( () => showToast( LP_Admin.i18n.error, 'error' ) );
    } );

    $( '#lp-export-btn' ).on( 'click', function () {
        // POST, so the nonce never ends up in a URL (logs, history, Referer).
        const form = document.createElement( 'form' );
        form.method = 'post';
        form.action = LP_Admin.ajaxUrl;
        form.style.display = 'none';
        [ [ 'action', 'lp_export' ], [ 'nonce', LP_Admin.nonce ] ].forEach( function ( [ name, value ] ) {
            const input = document.createElement( 'input' );
            input.type  = 'hidden';
            input.name  = name;
            input.value = value;
            form.appendChild( input );
        } );
        document.body.appendChild( form );
        form.submit();
        form.remove();
    } );

    $( '#lp-clear-cache' ).on( 'click', function () {
        const $btn    = $( this );
        const origText = $btn.text();
        $btn.prop( 'disabled', true ).text( '…' );
        $.post( LP_Admin.ajaxUrl, { action: 'lp_clear_cache', nonce: LP_Admin.nonce } )
            .done( function ( res ) {
                if ( res.success ) {
                    $btn.text( '✓' );
                    setTimeout( () => $btn.text( origText ), 2000 );
                } else {
                    showToast( res.data?.message || LP_Admin.i18n.error, 'error' );
                    $btn.text( origText );
                }
            } )
            .fail( function () {
                showToast( LP_Admin.i18n.error, 'error' );
                $btn.text( origText );
            } )
            .always( () => $btn.prop( 'disabled', false ) );
    } );

    $( '#lp-reinstall-db' ).on( 'click', function () {
        if ( ! confirm( LP_Admin.i18n.reinstallConfirm ) ) return;
        const $btn    = $( this );
        const origText = $btn.text();
        $btn.prop( 'disabled', true ).text( '…' );
        $.post( LP_Admin.ajaxUrl, { action: 'lp_reinstall_db', nonce: LP_Admin.nonce } )
            .done( function ( res ) {
                if ( res.success ) {
                    $btn.text( '✓' );
                    setTimeout( () => $btn.text( origText ), 2000 );
                } else {
                    showToast( res.data?.message || LP_Admin.i18n.error, 'error' );
                    $btn.text( origText );
                }
            } )
            .fail( function () {
                showToast( LP_Admin.i18n.error, 'error' );
                $btn.text( origText );
            } )
            .always( () => $btn.prop( 'disabled', false ) );
    } );

    // Keep the design preview in sync as the user adjusts color and size inputs.
    function updateDesignPreview() {
        $( '#lp-design-preview .lp-switcher' ).css( {
            '--lp-bg':        $( '#lp_bg_color' ).val()     || '#ffffff',
            '--lp-text':      $( '#lp_text_color' ).val()   || '#333333',
            '--lp-border':    $( '#lp_border_color' ).val() || '#cccccc',
            '--lp-hover':     $( '#lp_hover_color' ).val()  || '#f0f0f0',
            '--lp-radius':    ( $( '#lp_border_radius' ).val() || '4'  ) + 'px',
            '--lp-font-size': ( $( '#lp_font_size' ).val()    || '14' ) + 'px',
            '--lp-padding':   ( $( '#lp_padding' ).val()      || '8'  ) + 'px',
        } );
    }

    $( 'input[type="number"]' ).on( 'input', updateDesignPreview );

    updateDesignPreview();

} )( jQuery );
