<?php
defined( 'ABSPATH' ) || exit;

/**
 * All admin menus, settings pages, and AJAX handlers.
 */
class LP_Admin {

	private static ?self $instance = null;

	private function __construct() {
		add_action( 'admin_menu',            [ $this, 'register_menus' ] );
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_assets' ] );
		add_action( 'admin_init',            [ $this, 'handle_form_submissions' ] );

		add_action( 'wp_ajax_lp_save_translation',       [ $this, 'ajax_save_translation' ] );
		add_action( 'wp_ajax_lp_update_status',          [ $this, 'ajax_update_status' ] );
		add_action( 'wp_ajax_lp_delete_translation',     [ $this, 'ajax_delete_translation' ] );
		add_action( 'wp_ajax_lp_export',                 [ $this, 'ajax_export' ] );
		add_action( 'wp_ajax_lp_clear_cache',            [ $this, 'ajax_clear_cache' ] );
		add_action( 'wp_ajax_lp_reinstall_db',           [ $this, 'ajax_reinstall_db' ] );
		add_action( 'wp_ajax_lp_get_translation',        [ $this, 'ajax_get_translation' ] );
		add_action( 'wp_ajax_lp_get_page_translations',  [ $this, 'ajax_get_page_translations' ] );
		add_filter( 'plugin_action_links_' . LP_PLUGIN_BASENAME, [ $this, 'plugin_action_links' ] );
		add_action( 'admin_notices',  [ $this, 'notice_caching_plugin' ] );
		add_filter( 'admin_body_class', [ $this, 'maybe_add_dark_class' ] );
	}

	public static function instance(): self {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	// -------------------------------------------------------------------------
	// Dark mode
	// -------------------------------------------------------------------------

	public function maybe_add_dark_class( string $classes ): string {
		if ( ! get_option( 'lp_dark_mode', 0 ) ) {
			return $classes;
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$page    = sanitize_key( $_GET['page'] ?? '' );
		$lp_pages = [ 'lp-settings', 'lp-languages', 'lp-translations', 'lp-design', 'lp-import-export', 'lp-debug' ];
		if ( in_array( $page, $lp_pages, true ) ) {
			$classes .= ' lp-dark-mode';
		}
		return $classes;
	}

	// -------------------------------------------------------------------------
	// Menus
	// -------------------------------------------------------------------------

	public function register_menus(): void {
		add_menu_page(
			__( 'Website Translator', 'langpress' ),
			__( 'Translator', 'langpress' ),
			'manage_options',
			'lp-settings',
			[ $this, 'page_settings' ],
			'dashicons-translation',
			80
		);

		add_submenu_page(
			'lp-settings',
			__( 'Einstellungen', 'langpress' ),
			__( 'Einstellungen', 'langpress' ),
			'manage_options',
			'lp-settings',
			[ $this, 'page_settings' ]
		);

		add_submenu_page(
			'lp-settings',
			__( 'Sprachen', 'langpress' ),
			__( 'Sprachen', 'langpress' ),
			'manage_options',
			'lp-languages',
			[ $this, 'page_languages' ]
		);

		add_submenu_page(
			'lp-settings',
			__( 'Übersetzungen', 'langpress' ),
			__( 'Übersetzungen', 'langpress' ),
			'manage_options',
			'lp-translations',
			[ $this, 'page_translations' ]
		);

		add_submenu_page(
			'lp-settings',
			__( 'Design & Dropdown', 'langpress' ),
			__( 'Design', 'langpress' ),
			'manage_options',
			'lp-design',
			[ $this, 'page_design' ]
		);

		add_submenu_page(
			'lp-settings',
			__( 'Import / Export', 'langpress' ),
			__( 'Import / Export', 'langpress' ),
			'manage_options',
			'lp-import-export',
			[ $this, 'page_import_export' ]
		);

		add_submenu_page(
			'lp-settings',
			__( 'Debug / Status', 'langpress' ),
			__( 'Debug / Status', 'langpress' ),
			'manage_options',
			'lp-debug',
			[ $this, 'page_debug' ]
		);
	}

	// -------------------------------------------------------------------------
	// Assets
	// -------------------------------------------------------------------------

	public function enqueue_assets( string $hook ): void {
		$lp_pages = [
			'toplevel_page_lp-settings',
			'translator_page_lp-languages',
			'translator_page_lp-translations',
			'translator_page_lp-design',
			'translator_page_lp-import-export',
			'translator_page_lp-debug',
		];

		if ( ! in_array( $hook, $lp_pages, true ) ) {
			return;
		}

		wp_enqueue_style(
			'lp-admin',
			LP_PLUGIN_URL . 'admin/admin.css',
			[],
			LP_VERSION
		);

		wp_enqueue_style( 'wp-color-picker' );

		wp_enqueue_script(
			'lp-admin',
			LP_PLUGIN_URL . 'admin/admin.js',
			[ 'jquery', 'wp-color-picker' ],
			LP_VERSION,
			true
		);

		wp_localize_script( 'lp-admin', 'LP_Admin', [
			'ajaxUrl' => admin_url( 'admin-ajax.php' ),
			'nonce'   => wp_create_nonce( 'lp_admin_nonce' ),
			'i18n'    => [
				'saved'           => __( 'Gespeichert!', 'langpress' ),
				'saveBtn'         => __( 'Speichern', 'langpress' ),
				'error'           => __( 'Fehler beim Speichern.', 'langpress' ),
				'confirm'         => __( 'Wirklich löschen?', 'langpress' ),
				'deleted'         => __( 'Gelöscht.', 'langpress' ),
				'reinstallConfirm'=> __( 'Reinstall database tables? Existing data will be kept (dbDelta).', 'langpress' ),
				'active'          => __( 'Aktiv', 'langpress' ),
				'pending'         => __( 'Ausstehend', 'langpress' ),
				'ignored'         => __( 'Ignoriert', 'langpress' ),
			],
		] );
	}

	// -------------------------------------------------------------------------
	// Form submissions
	// -------------------------------------------------------------------------

	public function handle_form_submissions(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		if ( isset( $_POST['lp_save_settings'], $_POST['_wpnonce'] ) ) {
			if ( wp_verify_nonce( sanitize_key( $_POST['_wpnonce'] ), 'lp_settings_nonce' ) ) {
				$this->save_settings();
			}
		}

		if ( isset( $_POST['lp_save_languages'], $_POST['_wpnonce'] ) ) {
			if ( wp_verify_nonce( sanitize_key( $_POST['_wpnonce'] ), 'lp_languages_nonce' ) ) {
				$this->save_languages();
			}
		}

		if ( isset( $_POST['lp_save_design'], $_POST['_wpnonce'] ) ) {
			if ( wp_verify_nonce( sanitize_key( $_POST['_wpnonce'] ), 'lp_design_nonce' ) ) {
				$this->save_design();
			}
		}

		if ( isset( $_POST['lp_do_import'], $_POST['_wpnonce'] ) ) {
			if ( wp_verify_nonce( sanitize_key( $_POST['_wpnonce'] ), 'lp_import_nonce' ) ) {
				$this->process_import();
			}
		}
	}

	// -------------------------------------------------------------------------
	// Save handlers
	// -------------------------------------------------------------------------

	private function save_settings(): void {
		$display = sanitize_key( $_POST['lp_switcher_display'] ?? 'all' );
		if ( ! in_array( $display, [ 'all', 'specific', 'exclude' ], true ) ) {
			$display = 'all';
		}

		$position = sanitize_key( $_POST['lp_switcher_position'] ?? 'bottom-right' );
		$allowed_positions = [ 'top-left', 'top-right', 'bottom-left', 'bottom-right', 'shortcode-only' ];
		if ( ! in_array( $position, $allowed_positions, true ) ) {
			$position = 'bottom-right';
		}

		$pages = [];
		if ( isset( $_POST['lp_switcher_pages'] ) && is_array( $_POST['lp_switcher_pages'] ) ) {
			$pages = array_map( 'absint', $_POST['lp_switcher_pages'] );
		}

		update_option( 'lp_switcher_display',  $display );
		update_option( 'lp_switcher_position', $position );
		update_option( 'lp_switcher_pages',    $pages );
		update_option( 'lp_position_fixed',    isset( $_POST['lp_position_fixed'] ) ? 1 : 0 );
		update_option( 'lp_dark_mode',         isset( $_POST['lp_dark_mode'] ) ? 1 : 0 );
		update_option( 'lp_auto_scan',         isset( $_POST['lp_auto_scan'] ) ? 1 : 0 );
		update_option( 'lp_delete_data_on_uninstall', isset( $_POST['lp_delete_data_on_uninstall'] ) ? 1 : 0 );

		add_settings_error( 'lp', 'lp_saved', __( 'Einstellungen gespeichert.', 'langpress' ), 'success' );
	}

	private function save_languages(): void {
		$default = sanitize_key( $_POST['lp_default_language'] ?? 'de' );
		$all     = LP_Translator::available_languages();

		if ( ! isset( $all[ $default ] ) ) {
			$default = 'de';
		}

		$active = [];
		if ( isset( $_POST['lp_active_languages'] ) && is_array( $_POST['lp_active_languages'] ) ) {
			foreach ( $_POST['lp_active_languages'] as $lang ) {
				$lang = sanitize_key( $lang );
				if ( isset( $all[ $lang ] ) ) {
					$active[] = $lang;
				}
			}
		}

		if ( ! in_array( $default, $active, true ) ) {
			array_unshift( $active, $default );
		}

		update_option( 'lp_default_language',  $default );
		update_option( 'lp_active_languages',  $active );

		LP_Translator::instance()->invalidate_cache();

		add_settings_error( 'lp', 'lp_saved', __( 'Sprachen gespeichert.', 'langpress' ), 'success' );
	}

	private function save_design(): void {
		$style = sanitize_key( $_POST['lp_switcher_style'] ?? 'dropdown' );
		if ( ! in_array( $style, [ 'dropdown', 'buttons' ], true ) ) {
			$style = 'dropdown';
		}

		$mode = sanitize_key( $_POST['lp_display_mode'] ?? 'text' );
		if ( ! in_array( $mode, [ 'text', 'flag', 'both' ], true ) ) {
			$mode = 'text';
		}

		$color_fields = [ 'lp_bg_color', 'lp_text_color', 'lp_border_color', 'lp_hover_color' ];
		foreach ( $color_fields as $field ) {
			$val = sanitize_hex_color( $_POST[ $field ] ?? '#ffffff' ) ?: '#ffffff';
			update_option( $field, $val );
		}

		$num_fields = [
			'lp_border_radius' => [ 0, 50 ],
			'lp_font_size'     => [ 8, 32 ],
			'lp_padding'       => [ 0, 40 ],
		];
		foreach ( $num_fields as $field => [$min, $max] ) {
			$val = absint( $_POST[ $field ] ?? 0 );
			$val = max( $min, min( $max, $val ) );
			update_option( $field, (string) $val );
		}

		update_option( 'lp_switcher_style', $style );
		update_option( 'lp_display_mode',   $mode );

		add_settings_error( 'lp', 'lp_saved', __( 'Design gespeichert.', 'langpress' ), 'success' );
	}

	private function process_import(): void {
		if ( ! isset( $_FILES['lp_import_file'] ) || $_FILES['lp_import_file']['error'] !== UPLOAD_ERR_OK ) {
			add_settings_error( 'lp', 'lp_import_error', __( 'Keine Datei hochgeladen.', 'langpress' ), 'error' );
			return;
		}

		if ( $_FILES['lp_import_file']['size'] > 10 * 1024 * 1024 ) {
			add_settings_error( 'lp', 'lp_import_error', __( 'Datei zu groß. Maximum: 10 MB.', 'langpress' ), 'error' );
			return;
		}

		$tmp_file = $_FILES['lp_import_file']['tmp_name'];
		$ext      = strtolower( pathinfo( sanitize_file_name( $_FILES['lp_import_file']['name'] ), PATHINFO_EXTENSION ) );

		if ( $ext !== 'json' ) {
			add_settings_error( 'lp', 'lp_import_error', __( 'Nur JSON-Dateien werden unterstützt.', 'langpress' ), 'error' );
			return;
		}

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		$json    = file_get_contents( $tmp_file );
		$data    = json_decode( $json, true );
		$db      = LP_Database::instance();
		$count   = 0;

		if ( ! is_array( $data ) ) {
			$json_err = json_last_error() !== JSON_ERROR_NONE ? ' (' . json_last_error_msg() . ')' : '';
			add_settings_error( 'lp', 'lp_import_error', __( 'Ungültige JSON-Datei.', 'langpress' ) . esc_html( $json_err ), 'error' );
			return;
		}

		// Imported rows may target any supported language except the source language,
		// so an export round-trips even if some languages are currently switched off.
		$languages = array_diff( array_keys( LP_Translator::available_languages() ), [ get_option( 'lp_default_language', 'de' ) ] );

		foreach ( $data as $entry ) {
			if ( ! is_array( $entry ) || ! isset( $entry['original_text'], $entry['language_code'], $entry['translated_text'] ) ) {
				continue;
			}
			$original   = $db->clean_text( $entry['original_text'] );
			$translated = $db->clean_text( $entry['translated_text'] );
			$lang       = is_string( $entry['language_code'] ) ? $entry['language_code'] : '';
			if ( $original === '' || ! is_string( $entry['translated_text'] ) || ! in_array( $lang, $languages, true ) ) {
				continue;
			}
			// Entries without a status used to pass null on and abort the whole import with a TypeError.
			$status = $entry['status'] ?? 'active';
			if ( ! in_array( $status, [ 'active', 'pending', 'ignored' ], true ) ) {
				$status = 'active';
			}

			$ok = $db->upsert_translation( $original, $lang, $translated, $status );
			if ( $ok ) {
				$count++;
			}
		}

		LP_Translator::instance()->invalidate_cache();

		add_settings_error(
			'lp',
			'lp_import_success',
			sprintf( __( '%d Übersetzungen importiert.', 'langpress' ), $count ),
			'success'
		);
	}

	// -------------------------------------------------------------------------
	// AJAX-Handler
	// -------------------------------------------------------------------------

	public function ajax_save_translation(): void {
		check_ajax_referer( 'lp_admin_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( [ 'message' => 'Insufficient permissions.' ] );
		}

		// Plain text, kept verbatim (see LP_Database::clean_text()) so the hash matches the page.
		$db       = LP_Database::instance();
		$original = $db->clean_text( wp_unslash( $_POST['original'] ?? '' ) );
		$post_id  = absint( $_POST['post_id'] ?? 0 );

		if ( $original === '' ) {
			wp_send_json_error( [ 'message' => 'Missing original text.' ] );
		}

		$active_langs = (array) get_option( 'lp_active_languages', [ 'de', 'en', 'uk' ] );
		$default_lang = get_option( 'lp_default_language', 'de' );
		$target_langs = array_filter( $active_langs, fn( $l ) => $l !== $default_lang );

		// --- Multi-language save (from Translation Editor) ---
		// The editor sends each target lang as its own POST key (e.g. POST['en'], POST['uk'])
		$multi_langs = array_filter(
			$target_langs,
			fn( $l ) => isset( $_POST[ $l ] )
		);

		if ( ! empty( $multi_langs ) ) {
			$saved = [];
			foreach ( $multi_langs as $lang ) {
				$translated = $db->clean_text( wp_unslash( $_POST[ $lang ] ) );
				if ( $translated === '' ) {
					continue; // Don't overwrite existing with empty
				}
				if ( $db->upsert_translation( $original, $lang, $translated, 'active', '', $post_id ) ) {
					$saved[] = $lang;
					LP_Translator::instance()->invalidate_cache( $lang );
				}
			}

			if ( empty( $saved ) ) {
				wp_send_json_error( [ 'message' => __( 'Keine Übersetzungen eingegeben.', 'langpress' ) ] );
			}

			wp_send_json_success( [
				'message' => __( 'Gespeichert!', 'langpress' ),
				'langs'   => $saved,
			] );
			return;
		}

		// --- Legacy single-language save (from admin translations table) ---
		$lang       = sanitize_key( wp_unslash( $_POST['lang'] ?? '' ) );
		$translated = $db->clean_text( wp_unslash( $_POST['translated'] ?? '' ) );
		$status     = sanitize_key( wp_unslash( $_POST['status'] ?? 'active' ) );

		if ( ! in_array( $lang, $target_langs, true ) ) {
			wp_send_json_error( [ 'message' => 'Invalid language.' ] );
		}

		$allowed_status = [ 'active', 'pending', 'ignored' ];
		if ( ! in_array( $status, $allowed_status, true ) ) {
			$status = 'active';
		}

		if ( $translated !== '' && $status !== 'ignored' ) {
			$status = 'active';
		}

		$result = $db->upsert_translation( $original, $lang, $translated, $status, '', $post_id );

		if ( $result ) {
			LP_Translator::instance()->invalidate_cache( $lang );
			wp_send_json_success( [ 'message' => __( 'Gespeichert!', 'langpress' ) ] );
		} else {
			wp_send_json_error( [ 'message' => __( 'Fehler beim Speichern.', 'langpress' ) ] );
		}
	}

	public function ajax_update_status(): void {
		check_ajax_referer( 'lp_admin_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( [ 'message' => 'Insufficient permissions.' ] );
		}

		$id     = absint( $_POST['id'] ?? 0 );
		$status = sanitize_key( $_POST['status'] ?? '' );

		if ( ! $id ) {
			wp_send_json_error( [ 'message' => 'Invalid ID.' ] );
		}

		$result = LP_Database::instance()->update_status( $id, $status );
		LP_Translator::instance()->invalidate_cache();

		$result
			? wp_send_json_success()
			: wp_send_json_error( [ 'message' => 'Update failed.' ] );
	}

	public function ajax_delete_translation(): void {
		check_ajax_referer( 'lp_admin_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( [ 'message' => 'Insufficient permissions.' ] );
		}

		$hash = sanitize_text_field( wp_unslash( $_POST['hash'] ?? '' ) );
		if ( ! preg_match( '/^[a-f0-9]{64}$/', $hash ) ) {
			wp_send_json_error( [ 'message' => 'Invalid hash.' ] );
		}

		$result = LP_Database::instance()->delete_by_hash( $hash );
		LP_Translator::instance()->invalidate_cache();

		$result
			? wp_send_json_success()
			: wp_send_json_error( [ 'message' => 'Delete failed.' ] );
	}

	public function ajax_export(): void {
		check_ajax_referer( 'lp_admin_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Forbidden', 403 );
		}

		global $wpdb;
		$table = LP_Database::instance()->get_table_translations();

		$rows = $wpdb->get_results(
			"SELECT original_text, text_hash, language_code, translated_text, status, page_url
			 FROM $table
			 ORDER BY language_code, text_hash",
			ARRAY_A
		);

		$filename = 'lp-export-' . gmdate( 'Y-m-d' ) . '.json';

		// Exported strings (including page_url) are data. nosniff makes sure no
		// browser ever renders the download as HTML.
		nocache_headers();
		header( 'Content-Type: application/json; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="' . $filename . '"' );
		header( 'X-Content-Type-Options: nosniff' );

		// phpcs:ignore WordPress.WP.AlternativeFunctions.json_encode_json_encode
		echo json_encode( $rows, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE );
		exit;
	}

	public function ajax_clear_cache(): void {
		check_ajax_referer( 'lp_admin_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( [ 'message' => 'Insufficient permissions.' ] );
		}

		LP_Translator::instance()->invalidate_cache();
		wp_send_json_success( [ 'message' => __( 'Cache geleert.', 'langpress' ) ] );
	}

	public function ajax_reinstall_db(): void {
		check_ajax_referer( 'lp_admin_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( [ 'message' => 'Insufficient permissions.' ] );
		}

		LP_Database::instance()->install();
		wp_send_json_success( [ 'message' => 'DB neu installiert.' ] );
	}

	/**
	 * Alle Übersetzungen für eine Sprache/Seite liefern (für Inline-Sprachwechsel).
	 */
	public function ajax_get_page_translations(): void {
		check_ajax_referer( 'lp_admin_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( [ 'message' => 'Insufficient permissions.' ] );
		}

		$lang    = sanitize_key( wp_unslash( $_POST['language_code'] ?? $_POST['lang'] ?? '' ) );
		$post_id = absint( $_POST['post_id'] ?? 0 );

		if ( ! in_array( $lang, (array) get_option( 'lp_active_languages', [ 'de', 'en', 'uk' ] ), true ) ) {
			wp_send_json_error( [ 'message' => 'Invalid language_code.' ] );
		}

		$translations = LP_Database::instance()->get_translations_for_language( $lang );

		wp_send_json_success( [
			'lang'         => $lang,
			'post_id'      => $post_id,
			'translations' => $translations,
		] );
	}

	/**
	 * Vorhandene Übersetzungen für einen Originaltext laden.
	 * Wird vom Frontend-Translate-Mode aufgerufen.
	 */
	public function ajax_get_translation(): void {
		check_ajax_referer( 'lp_admin_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( [ 'message' => 'Insufficient permissions.' ] );
		}

		$db       = LP_Database::instance();
		$original = $db->clean_text( wp_unslash( $_POST['original'] ?? '' ) );
		if ( $original === '' ) {
			wp_send_json_error( [ 'message' => 'Missing text.' ] );
		}

		$hash         = $db->hash( $original );
		$active_langs = (array) get_option( 'lp_active_languages', [ 'de', 'en', 'uk' ] );
		$default_lang = get_option( 'lp_default_language', 'de' );
		$translations = [];

		$normalized = $db->normalize( $original );

		foreach ( $active_langs as $lang ) {
			if ( $lang === $default_lang ) {
				continue;
			}

			// Primary lookup by normalized hash (current format).
			$translated = $db->get_translation( $hash, $lang );

			// Fallback 1: match by original_text column. Covers rows saved by older
			// versions whose text_hash was computed with a different algorithm.
			if ( $translated === null ) {
				$translated = $db->get_translation_by_original_text( $original, $lang );
			}

			// Fallback 2: match by normalized_text column. Covers whitespace variants.
			if ( $translated === null ) {
				$translated = $db->get_translation_by_normalized( $normalized, $lang );
			}

			$translations[ $lang ] = $translated ?? '';
		}

		wp_send_json_success( [
			'hash'         => $hash,
			'original'     => $original,
			'translations' => $translations,
		] );
	}

	// -------------------------------------------------------------------------
	// Admin pages
	// -------------------------------------------------------------------------

	public function page_settings(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Zugriff verweigert.', 'langpress' ) );
		}

		settings_errors( 'lp' );
		$pages    = get_pages();
		$display  = get_option( 'lp_switcher_display', 'all' );
		$position = get_option( 'lp_switcher_position', 'bottom-right' );
		$sel_pages= (array) get_option( 'lp_switcher_pages', [] );
		$fixed    = (bool) get_option( 'lp_position_fixed', false );
		?>
		<div class="wrap lp-wrap">
			<h1><?php esc_html_e( 'LangPress – Einstellungen', 'langpress' ); ?></h1>
			<?php $this->render_nav( 'lp-settings' ); ?>

			<form method="post" class="lp-form">
				<?php wp_nonce_field( 'lp_settings_nonce' ); ?>

				<div class="lp-card">
					<h2><?php esc_html_e( 'Sprachumschalter-Sichtbarkeit', 'langpress' ); ?></h2>

					<table class="form-table">
						<tr>
							<th><label for="lp_switcher_display"><?php esc_html_e( 'Anzeigen auf', 'langpress' ); ?></label></th>
							<td>
								<select name="lp_switcher_display" id="lp_switcher_display">
									<option value="all" <?php selected( $display, 'all' ); ?>><?php esc_html_e( 'Allen Seiten', 'langpress' ); ?></option>
									<option value="specific" <?php selected( $display, 'specific' ); ?>><?php esc_html_e( 'Nur bestimmten Seiten', 'langpress' ); ?></option>
									<option value="exclude" <?php selected( $display, 'exclude' ); ?>><?php esc_html_e( 'Allen außer bestimmten', 'langpress' ); ?></option>
								</select>
							</td>
						</tr>
						<tr class="lp-page-selector" style="<?php echo $display === 'all' ? 'display:none' : ''; ?>">
							<th><label><?php esc_html_e( 'Seiten auswählen', 'langpress' ); ?></label></th>
							<td>
								<div class="lp-page-list">
								<?php foreach ( $pages as $page ) : ?>
									<label>
										<input type="checkbox"
											   name="lp_switcher_pages[]"
											   value="<?php echo esc_attr( $page->ID ); ?>"
											   <?php checked( in_array( $page->ID, $sel_pages, true ) ); ?>>
										<?php echo esc_html( $page->post_title ); ?>
									</label><br>
								<?php endforeach; ?>
								</div>
							</td>
						</tr>
						<tr>
							<th><label for="lp_switcher_position"><?php esc_html_e( 'Position', 'langpress' ); ?></label></th>
							<td>
								<select name="lp_switcher_position" id="lp_switcher_position">
									<?php
									$positions = [
										'top-left'      => __( 'Oben links', 'langpress' ),
										'top-right'     => __( 'Oben rechts', 'langpress' ),
										'bottom-left'   => __( 'Unten links', 'langpress' ),
										'bottom-right'  => __( 'Unten rechts', 'langpress' ),
										'shortcode-only'=> __( 'Nur Shortcode', 'langpress' ),
									];
									foreach ( $positions as $val => $label ) :
									?>
										<option value="<?php echo esc_attr( $val ); ?>" <?php selected( $position, $val ); ?>>
											<?php echo esc_html( $label ); ?>
										</option>
									<?php endforeach; ?>
								</select>
							</td>
						</tr>
						<tr>
							<th><?php esc_html_e( 'Fixed-Position', 'langpress' ); ?></th>
							<td>
								<label>
									<input type="checkbox" name="lp_position_fixed" value="1" <?php checked( $fixed ); ?>>
									<?php esc_html_e( 'Switcher fest am Bildschirmrand fixieren (position: fixed)', 'langpress' ); ?>
								</label>
							</td>
						</tr>
						<tr>
							<th><?php esc_html_e( 'Dark Mode', 'langpress' ); ?></th>
							<td>
								<label>
									<input type="checkbox" name="lp_dark_mode" value="1" <?php checked( (bool) get_option( 'lp_dark_mode', 0 ) ); ?>>
									<?php esc_html_e( 'Enable dark mode for the LangPress admin UI', 'langpress' ); ?>
								</label>
							</td>
						</tr>
						<tr>
							<th><?php esc_html_e( 'Automatic text detection', 'langpress' ); ?></th>
							<td>
								<label>
									<input type="checkbox" name="lp_auto_scan" value="1" <?php checked( (bool) get_option( 'lp_auto_scan', 1 ) ); ?>>
									<?php esc_html_e( 'Register new texts when pages are viewed in the default language', 'langpress' ); ?>
								</label>
								<p class="description"><?php esc_html_e( 'Each page is scanned at most once a day and again after it is edited. Search results, 404 pages and URLs with unknown query parameters are never scanned.', 'langpress' ); ?></p>
							</td>
						</tr>
						<tr>
							<th><?php esc_html_e( 'Uninstall', 'langpress' ); ?></th>
							<td>
								<label>
									<input type="checkbox" name="lp_delete_data_on_uninstall" value="1" <?php checked( (bool) get_option( 'lp_delete_data_on_uninstall', 0 ) ); ?>>
									<?php esc_html_e( 'Delete all translations and LangPress settings when the plugin is deleted', 'langpress' ); ?>
								</label>
								<p class="description"><?php esc_html_e( 'Off by default, so translations survive a reinstall. This cannot be undone, so export your translations first.', 'langpress' ); ?></p>
							</td>
						</tr>
					</table>
				</div>

				<p class="lp-shortcode-info">
					<?php esc_html_e( 'Shortcode:', 'langpress' ); ?>
					<code>[langpress_switcher]</code>
				</p>

				<p class="submit">
					<button type="submit" name="lp_save_settings" class="button button-primary">
						<?php esc_html_e( 'Einstellungen speichern', 'langpress' ); ?>
					</button>
				</p>
			</form>
		</div>
		<?php
	}

	public function page_languages(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Zugriff verweigert.', 'langpress' ) );
		}

		settings_errors( 'lp' );
		$all_langs   = LP_Translator::available_languages();
		$active      = (array) get_option( 'lp_active_languages', [ 'de', 'en', 'uk' ] );
		$default     = get_option( 'lp_default_language', 'de' );
		?>
		<div class="wrap lp-wrap">
			<h1><?php esc_html_e( 'LangPress – Sprachen', 'langpress' ); ?></h1>
			<?php $this->render_nav( 'lp-languages' ); ?>

			<form method="post" class="lp-form">
				<?php wp_nonce_field( 'lp_languages_nonce' ); ?>

				<div class="lp-card">
					<h2><?php esc_html_e( 'Standardsprache', 'langpress' ); ?></h2>
					<table class="form-table">
						<tr>
							<th><label for="lp_default_language"><?php esc_html_e( 'Hauptsprache', 'langpress' ); ?></label></th>
							<td>
								<select name="lp_default_language" id="lp_default_language">
									<?php foreach ( $all_langs as $code => $meta ) : ?>
										<option value="<?php echo esc_attr( $code ); ?>" <?php selected( $default, $code ); ?>>
											<?php echo esc_html( $meta['flag'] . ' ' . $meta['label'] . ' (' . $meta['native'] . ')' ); ?>
										</option>
									<?php endforeach; ?>
								</select>
								<p class="description"><?php esc_html_e( 'Texte auf der Website sind in dieser Sprache verfasst.', 'langpress' ); ?></p>
							</td>
						</tr>
					</table>
				</div>

				<div class="lp-card">
					<h2><?php esc_html_e( 'Aktive Übersetzungssprachen', 'langpress' ); ?></h2>
					<p class="description"><?php esc_html_e( 'Wähle alle Sprachen, in die übersetzt werden soll.', 'langpress' ); ?></p>
					<div class="lp-lang-grid">
						<?php foreach ( $all_langs as $code => $meta ) : ?>
							<label class="lp-lang-card <?php echo in_array( $code, $active, true ) ? 'lp-lang-card--active' : ''; ?>">
								<input type="checkbox"
									   name="lp_active_languages[]"
									   value="<?php echo esc_attr( $code ); ?>"
									   <?php checked( in_array( $code, $active, true ) ); ?>>
								<span class="lp-lang-flag"><?php echo esc_html( $meta['flag'] ); ?></span>
								<span class="lp-lang-name"><?php echo esc_html( $meta['label'] ); ?></span>
								<span class="lp-lang-native"><?php echo esc_html( $meta['native'] ); ?></span>
								<span class="lp-lang-code"><?php echo esc_html( strtoupper( $code ) ); ?></span>
							</label>
						<?php endforeach; ?>
					</div>
				</div>

				<p class="submit">
					<button type="submit" name="lp_save_languages" class="button button-primary">
						<?php esc_html_e( 'Sprachen speichern', 'langpress' ); ?>
					</button>
				</p>
			</form>
		</div>
		<?php
	}

	public function page_translations(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Zugriff verweigert.', 'langpress' ) );
		}

		$db           = LP_Database::instance();
		$active_langs = (array) get_option( 'lp_active_languages', [ 'de', 'en', 'uk' ] );
		$default_lang = get_option( 'lp_default_language', 'de' );
		$all_langs    = LP_Translator::available_languages();

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$paged        = max( 1, absint( $_GET['paged'] ?? 1 ) );
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$search       = sanitize_text_field( wp_unslash( $_GET['s'] ?? '' ) );
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$status_filter= sanitize_key( $_GET['status_filter'] ?? '' );
		$per_page     = 20;

		$result       = $db->get_all_originals( $per_page, $paged, $search, $status_filter );
		$items        = $result['items'];
		$total        = $result['total'];
		$total_pages  = (int) ceil( $total / $per_page );
		$target_langs = array_filter( $active_langs, fn( $l ) => $l !== $default_lang );
		?>
		<div class="wrap lp-wrap">
			<h1><?php esc_html_e( 'LangPress – Übersetzungen', 'langpress' ); ?></h1>
			<?php $this->render_nav( 'lp-translations' ); ?>

			<div class="lp-translations-header">
				<form method="get" class="lp-search-form">
					<input type="hidden" name="page" value="lp-translations">
					<input type="search"
						   name="s"
						   value="<?php echo esc_attr( $search ); ?>"
						   placeholder="<?php esc_attr_e( 'Originaltext suchen...', 'langpress' ); ?>"
						   class="lp-search-input">
					<select name="status_filter">
						<option value=""><?php esc_html_e( 'Alle Status', 'langpress' ); ?></option>
						<option value="pending"  <?php selected( $status_filter, 'pending' ); ?>><?php esc_html_e( 'Ausstehend', 'langpress' ); ?></option>
						<option value="active"   <?php selected( $status_filter, 'active' ); ?>><?php esc_html_e( 'Aktiv', 'langpress' ); ?></option>
						<option value="ignored"  <?php selected( $status_filter, 'ignored' ); ?>><?php esc_html_e( 'Ignoriert', 'langpress' ); ?></option>
					</select>
					<button type="submit" class="button"><?php esc_html_e( 'Filtern', 'langpress' ); ?></button>
				</form>
				<span class="lp-total-count">
					<?php printf( esc_html__( '%d Einträge', 'langpress' ), $total ); ?>
				</span>
			</div>

			<?php if ( empty( $items ) ) : ?>
				<div class="lp-empty-state">
					<p><?php esc_html_e( 'Keine Texte gefunden. Besuche deine Website, damit Texte automatisch erkannt werden.', 'langpress' ); ?></p>
				</div>
			<?php else : ?>

				<div class="lp-translations-table-wrap">
					<table class="lp-translations-table">
						<thead>
							<tr>
								<th class="col-original"><?php esc_html_e( 'Originaltext', 'langpress' ); ?></th>
								<?php foreach ( $target_langs as $lang ) : ?>
									<?php $meta = $all_langs[ $lang ] ?? [ 'flag' => '', 'label' => $lang ]; ?>
									<th class="col-translation">
										<?php echo esc_html( $meta['flag'] . ' ' . $meta['label'] ); ?>
									</th>
								<?php endforeach; ?>
								<th class="col-actions"><?php esc_html_e( 'Aktionen', 'langpress' ); ?></th>
							</tr>
						</thead>
						<tbody>
						<?php foreach ( $items as $item ) :
							$hash         = $item['text_hash'];
							$original     = $item['original_text'];
							$translations = $item['translations'];
						?>
							<tr class="lp-translation-row" data-hash="<?php echo esc_attr( $hash ); ?>">
								<td class="col-original">
									<div class="lp-original-text"><?php echo esc_html( $original ); ?></div>
									<?php if ( $item['page_url'] ) : ?>
										<div class="lp-source-url">
											<small><?php echo esc_html( $item['page_url'] ); ?></small>
										</div>
									<?php endif; ?>
								</td>

								<?php foreach ( $target_langs as $lang ) :
									$entry   = $translations[ $lang ] ?? null;
									$trans   = $entry['translated_text'] ?? '';
									$status  = $entry['status'] ?? 'pending';
									$entry_id= $entry['id'] ?? 0;
								?>
									<td class="col-translation lp-lang-cell"
										data-lang="<?php echo esc_attr( $lang ); ?>"
										data-entry-id="<?php echo esc_attr( $entry_id ); ?>">
										<div class="lp-status-badge lp-status--<?php echo esc_attr( $status ); ?>">
											<?php echo esc_html( $this->status_label( $status ) ); ?>
										</div>
										<textarea class="lp-translation-input"
												  rows="2"
												  data-lang="<?php echo esc_attr( $lang ); ?>"
												  data-hash="<?php echo esc_attr( $hash ); ?>"
												  data-original="<?php echo esc_attr( $original ); ?>"
												  placeholder="<?php esc_attr_e( 'Übersetzung eingeben…', 'langpress' ); ?>"
										><?php echo esc_textarea( $trans ); ?></textarea>
										<div class="lp-cell-actions">
											<select class="lp-status-select"
													data-entry-id="<?php echo esc_attr( $entry_id ); ?>">
												<option value="active"   <?php selected( $status, 'active' ); ?>><?php esc_html_e( 'Aktiv', 'langpress' ); ?></option>
												<option value="pending"  <?php selected( $status, 'pending' ); ?>><?php esc_html_e( 'Ausstehend', 'langpress' ); ?></option>
												<option value="ignored"  <?php selected( $status, 'ignored' ); ?>><?php esc_html_e( 'Ignorieren', 'langpress' ); ?></option>
											</select>
											<button type="button"
													class="button button-small lp-save-translation"
													data-lang="<?php echo esc_attr( $lang ); ?>"
													data-hash="<?php echo esc_attr( $hash ); ?>"
													data-original="<?php echo esc_attr( $original ); ?>">
												<?php esc_html_e( 'Speichern', 'langpress' ); ?>
											</button>
										</div>
									</td>
								<?php endforeach; ?>

								<td class="col-actions">
									<?php if ( ! empty( $translations ) ) :
										$first = reset( $translations );
									?>
										<button type="button"
												class="button button-small button-link-delete lp-delete-translation">
											<?php esc_html_e( 'Löschen', 'langpress' ); ?>
										</button>
									<?php endif; ?>
								</td>
							</tr>
						<?php endforeach; ?>
						</tbody>
					</table>
				</div>

				<?php if ( $total_pages > 1 ) : ?>
					<div class="lp-pagination">
						<?php
						$pagination_args = [
							'base'      => add_query_arg( 'paged', '%#%' ),
							'format'    => '',
							'current'   => $paged,
							'total'     => $total_pages,
							'prev_text' => '&laquo;',
							'next_text' => '&raquo;',
						];
						// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
						echo paginate_links( $pagination_args );
						?>
					</div>
				<?php endif; ?>

			<?php endif; ?>
		</div>
		<?php
	}

	public function page_design(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Zugriff verweigert.', 'langpress' ) );
		}

		settings_errors( 'lp' );

		$opts = [
			'lp_switcher_style' => get_option( 'lp_switcher_style', 'dropdown' ),
			'lp_display_mode'   => get_option( 'lp_display_mode', 'text' ),
			'lp_bg_color'       => get_option( 'lp_bg_color', '#ffffff' ),
			'lp_text_color'     => get_option( 'lp_text_color', '#333333' ),
			'lp_border_color'   => get_option( 'lp_border_color', '#cccccc' ),
			'lp_hover_color'    => get_option( 'lp_hover_color', '#f0f0f0' ),
			'lp_border_radius'  => get_option( 'lp_border_radius', '4' ),
			'lp_font_size'      => get_option( 'lp_font_size', '14' ),
			'lp_padding'        => get_option( 'lp_padding', '8' ),
		];
		?>
		<div class="wrap lp-wrap">
			<h1><?php esc_html_e( 'LangPress – Design & Dropdown', 'langpress' ); ?></h1>
			<?php $this->render_nav( 'lp-design' ); ?>

			<form method="post" class="lp-form">
				<?php wp_nonce_field( 'lp_design_nonce' ); ?>

				<div class="lp-design-columns">
					<div class="lp-card">
						<h2><?php esc_html_e( 'Darstellung', 'langpress' ); ?></h2>
						<table class="form-table">
							<tr>
								<th><?php esc_html_e( 'Stil', 'langpress' ); ?></th>
								<td>
									<label><input type="radio" name="lp_switcher_style" value="dropdown" <?php checked( $opts['lp_switcher_style'], 'dropdown' ); ?>>
										<?php esc_html_e( 'Dropdown-Menü', 'langpress' ); ?>
									</label><br>
									<label><input type="radio" name="lp_switcher_style" value="buttons" <?php checked( $opts['lp_switcher_style'], 'buttons' ); ?>>
										<?php esc_html_e( 'Schaltflächen', 'langpress' ); ?>
									</label>
								</td>
							</tr>
							<tr>
								<th><?php esc_html_e( 'Sprach-Anzeige', 'langpress' ); ?></th>
								<td>
									<label><input type="radio" name="lp_display_mode" value="text" <?php checked( $opts['lp_display_mode'], 'text' ); ?>>
										<?php esc_html_e( 'Text', 'langpress' ); ?>
									</label><br>
									<label><input type="radio" name="lp_display_mode" value="flag" <?php checked( $opts['lp_display_mode'], 'flag' ); ?>>
										<?php esc_html_e( 'Flagge', 'langpress' ); ?>
									</label><br>
									<label><input type="radio" name="lp_display_mode" value="both" <?php checked( $opts['lp_display_mode'], 'both' ); ?>>
										<?php esc_html_e( 'Text + Flagge', 'langpress' ); ?>
									</label>
								</td>
							</tr>
						</table>
					</div>

					<div class="lp-card">
						<h2><?php esc_html_e( 'Farben', 'langpress' ); ?></h2>
						<table class="form-table">
							<?php
							$color_fields = [
								'lp_bg_color'     => __( 'Hintergrundfarbe', 'langpress' ),
								'lp_text_color'   => __( 'Textfarbe', 'langpress' ),
								'lp_border_color' => __( 'Rahmenfarbe', 'langpress' ),
								'lp_hover_color'  => __( 'Hover-Hintergrund', 'langpress' ),
							];
							foreach ( $color_fields as $key => $label ) :
							?>
								<tr>
									<th><label for="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></label></th>
									<td>
										<input type="text"
											   id="<?php echo esc_attr( $key ); ?>"
											   name="<?php echo esc_attr( $key ); ?>"
											   value="<?php echo esc_attr( $opts[ $key ] ); ?>"
											   class="lp-color-picker">
									</td>
								</tr>
							<?php endforeach; ?>
						</table>
					</div>

					<div class="lp-card">
						<h2><?php esc_html_e( 'Abstände & Größen', 'langpress' ); ?></h2>
						<table class="form-table">
							<?php
							$num_fields = [
								'lp_border_radius' => [ __( 'Border-Radius (px)', 'langpress' ), 0, 50 ],
								'lp_font_size'     => [ __( 'Schriftgröße (px)', 'langpress' ), 8, 32 ],
								'lp_padding'       => [ __( 'Padding (px)', 'langpress' ), 0, 40 ],
							];
							foreach ( $num_fields as $key => [$label, $min, $max] ) :
							?>
								<tr>
									<th><label for="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></label></th>
									<td>
										<input type="number"
											   id="<?php echo esc_attr( $key ); ?>"
											   name="<?php echo esc_attr( $key ); ?>"
											   value="<?php echo esc_attr( $opts[ $key ] ); ?>"
											   min="<?php echo esc_attr( $min ); ?>"
											   max="<?php echo esc_attr( $max ); ?>"
											   class="small-text">
									</td>
								</tr>
							<?php endforeach; ?>
						</table>
					</div>
				</div>

				<div class="lp-card lp-preview-card">
					<h2><?php esc_html_e( 'Vorschau', 'langpress' ); ?></h2>
					<div id="lp-design-preview">
						<!-- Wird per JS aktualisiert -->
						<?php
						// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
						echo LP_Language_Switcher::instance()->render( true );
						?>
					</div>
				</div>

				<p class="submit">
					<button type="submit" name="lp_save_design" class="button button-primary">
						<?php esc_html_e( 'Design speichern', 'langpress' ); ?>
					</button>
				</p>
			</form>
		</div>
		<?php
	}

	public function page_import_export(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Zugriff verweigert.', 'langpress' ) );
		}

		settings_errors( 'lp' );
		?>
		<div class="wrap lp-wrap">
			<h1><?php esc_html_e( 'LangPress – Import / Export', 'langpress' ); ?></h1>
			<?php $this->render_nav( 'lp-import-export' ); ?>

			<div class="lp-columns-2">
				<div class="lp-card">
					<h2><?php esc_html_e( 'Export', 'langpress' ); ?></h2>
					<p><?php esc_html_e( 'Alle Übersetzungen als JSON-Datei herunterladen.', 'langpress' ); ?></p>
					<form method="post">
						<?php wp_nonce_field( 'lp_admin_nonce', '_wpnonce' ); ?>
						<button type="button" id="lp-export-btn" class="button button-primary">
							<?php esc_html_e( 'JSON exportieren', 'langpress' ); ?>
						</button>
					</form>
				</div>

				<div class="lp-card">
					<h2><?php esc_html_e( 'Import', 'langpress' ); ?></h2>
					<p><?php esc_html_e( 'JSON-Datei importieren (zuvor exportiertes Format).', 'langpress' ); ?></p>
					<form method="post" enctype="multipart/form-data">
						<?php wp_nonce_field( 'lp_import_nonce' ); ?>
						<input type="file" name="lp_import_file" accept=".json" class="lp-file-input">
						<br><br>
						<button type="submit" name="lp_do_import" class="button button-primary">
							<?php esc_html_e( 'JSON importieren', 'langpress' ); ?>
						</button>
					</form>
				</div>
			</div>
		</div>
		<?php
	}

	public function page_debug(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Zugriff verweigert.', 'langpress' ) );
		}

		global $wpdb;
		$stats       = LP_Database::instance()->get_stats();
		$table       = LP_Database::instance()->get_table_translations();
		$table_exists= $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) === $table;
		$php_version = PHP_VERSION;
		$wp_version  = get_bloginfo( 'version' );
		$active_lang = LP_Translator::instance()->get_current_language();
		?>
		<div class="wrap lp-wrap">
			<h1><?php esc_html_e( 'LangPress – Debug / Status', 'langpress' ); ?></h1>
			<?php $this->render_nav( 'lp-debug' ); ?>

			<div class="lp-columns-2">
				<div class="lp-card">
					<h2><?php esc_html_e( 'System-Status', 'langpress' ); ?></h2>
					<table class="lp-status-table">
						<tr>
							<td><?php esc_html_e( 'Plugin-Version', 'langpress' ); ?></td>
							<td><strong><?php echo esc_html( LP_VERSION ); ?></strong></td>
						</tr>
						<tr>
							<td><?php esc_html_e( 'WordPress', 'langpress' ); ?></td>
							<td><strong><?php echo esc_html( $wp_version ); ?></strong></td>
						</tr>
						<tr>
							<td><?php esc_html_e( 'PHP', 'langpress' ); ?></td>
							<td><strong><?php echo esc_html( $php_version ); ?></strong>
								<?php if ( version_compare( $php_version, '8.1', '>=' ) ) : ?>
									<span class="lp-ok">✓</span>
								<?php else : ?>
									<span class="lp-warn">PHP 8.1+ empfohlen</span>
								<?php endif; ?>
							</td>
						</tr>
						<tr>
							<td><?php esc_html_e( 'Datenbanktabelle', 'langpress' ); ?></td>
							<td>
								<?php if ( $table_exists ) : ?>
									<span class="lp-ok">✓ <?php echo esc_html( $table ); ?></span>
								<?php else : ?>
									<span class="lp-error">✗ <?php esc_html_e( 'Tabelle fehlt!', 'langpress' ); ?></span>
								<?php endif; ?>
							</td>
						</tr>
						<tr>
							<td><?php esc_html_e( 'DOM-Extension', 'langpress' ); ?></td>
							<td>
								<?php if ( extension_loaded( 'dom' ) ) : ?>
									<span class="lp-ok">✓ geladen</span>
								<?php else : ?>
									<span class="lp-error">✗ fehlt – Plugin kann Texte nicht übersetzen!</span>
								<?php endif; ?>
							</td>
						</tr>
						<tr>
							<td><?php esc_html_e( 'Aktive Sprache (aktueller Request)', 'langpress' ); ?></td>
							<td><strong><?php echo esc_html( strtoupper( $active_lang ) ); ?></strong></td>
						</tr>
					</table>
				</div>

				<div class="lp-card">
					<h2><?php esc_html_e( 'Übersetzungs-Statistiken', 'langpress' ); ?></h2>
					<table class="lp-status-table">
						<tr>
							<td><?php esc_html_e( 'Einzigartige Originaltexte', 'langpress' ); ?></td>
							<td><strong><?php echo esc_html( $stats['total_originals'] ); ?></strong></td>
						</tr>
						<tr>
							<td><?php esc_html_e( 'Aktive Übersetzungen', 'langpress' ); ?></td>
							<td><strong class="lp-ok"><?php echo esc_html( $stats['active'] ); ?></strong></td>
						</tr>
						<tr>
							<td><?php esc_html_e( 'Ausstehend', 'langpress' ); ?></td>
							<td><strong class="lp-warn"><?php echo esc_html( $stats['pending'] ); ?></strong></td>
						</tr>
						<tr>
							<td><?php esc_html_e( 'Ignoriert', 'langpress' ); ?></td>
							<td><strong><?php echo esc_html( $stats['ignored'] ); ?></strong></td>
						</tr>
					</table>

					<br>
					<button type="button" id="lp-clear-cache" class="button">
						<?php esc_html_e( 'Übersetzungs-Cache leeren', 'langpress' ); ?>
					</button>
					<button type="button" id="lp-reinstall-db" class="button">
						<?php esc_html_e( 'Datenbank neu installieren', 'langpress' ); ?>
					</button>
				</div>
			</div>
		</div>
		<?php
	}

	// -------------------------------------------------------------------------
	// Helpers
	// -------------------------------------------------------------------------

	private function render_nav( string $current ): void {
		$tabs = [
			'lp-settings'      => __( 'Einstellungen', 'langpress' ),
			'lp-languages'     => __( 'Sprachen', 'langpress' ),
			'lp-translations'  => __( 'Übersetzungen', 'langpress' ),
			'lp-design'        => __( 'Design', 'langpress' ),
			'lp-import-export' => __( 'Import / Export', 'langpress' ),
			'lp-debug'         => __( 'Debug', 'langpress' ),
		];
		echo '<nav class="lp-tab-nav">';
		foreach ( $tabs as $slug => $label ) {
			$class = $slug === $current ? 'lp-tab lp-tab--active' : 'lp-tab';
			$url   = esc_url( admin_url( 'admin.php?page=' . $slug ) );
			echo '<a href="' . $url . '" class="' . esc_attr( $class ) . '">' . esc_html( $label ) . '</a>';
		}
		echo '</nav>';
	}

	private function status_label( string $status ): string {
		return match ( $status ) {
			'active'  => __( 'Aktiv', 'langpress' ),
			'ignored' => __( 'Ignoriert', 'langpress' ),
			default   => __( 'Ausstehend', 'langpress' ),
		};
	}

	public function notice_caching_plugin(): void {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$page = sanitize_key( wp_unslash( $_GET['page'] ?? '' ) );
		if ( strpos( $page, 'lp-' ) !== 0 ) {
			return;
		}

		if ( ! function_exists( 'is_plugin_active' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		$known = [
			'wp-rocket/wp-rocket.php'             => 'WP Rocket',
			'w3-total-cache/w3-total-cache.php'   => 'W3 Total Cache',
			'litespeed-cache/litespeed-cache.php' => 'LiteSpeed Cache',
			'wp-super-cache/wp-cache.php'         => 'WP Super Cache',
			'cache-enabler/cache-enabler.php'     => 'Cache Enabler',
			'comet-cache/comet-cache.php'         => 'Comet Cache',
		];

		$found = [];
		foreach ( $known as $file => $name ) {
			if ( is_plugin_active( $file ) ) {
				$found[] = $name;
			}
		}

		if ( empty( $found ) ) {
			return;
		}

		$names   = '<strong>' . esc_html( implode( ', ', $found ) ) . '</strong>';
		$message = sprintf(
			/* translators: %s: comma-separated list of caching plugin names */
			__( '%s detected. Page caching can bypass LangPress\'s output buffer, so translations may not appear on cached pages. Exclude translated URLs from your cache, or flush the cache after saving translations.', 'langpress' ),
			$names
		);

		echo '<div class="notice notice-warning"><p>';
		echo '<strong>' . esc_html__( 'LangPress:', 'langpress' ) . '</strong> ';
		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo wp_kses_post( $message );
		echo '</p></div>';
	}

	public function plugin_action_links( array $links ): array {
		$settings_link = '<a href="' . esc_url( admin_url( 'admin.php?page=lp-settings' ) ) . '">'
					   . esc_html__( 'Einstellungen', 'langpress' )
					   . '</a>';
		array_unshift( $links, $settings_link );
		return $links;
	}
}
